export const json = <T>(data: T): string => JSON.stringify(data);
